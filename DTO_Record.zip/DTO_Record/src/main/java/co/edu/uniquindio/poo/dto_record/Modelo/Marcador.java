package co.edu.uniquindio.poo.dto_record.Modelo;

public record Marcador(Equipo equipo, String Marcador,Equipo equipo2, String Codigo) {
}
