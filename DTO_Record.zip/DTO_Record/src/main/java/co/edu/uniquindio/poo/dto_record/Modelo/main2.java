package co.edu.uniquindio.poo.dto_record.Modelo;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

import java.io.File;
import java.io.IOException;

public class main2 {
    public static void main(String[] args) throws IOException {
        Competencia competencia = new Competencia("djjs");
        System.out.println(competencia);

        Jugador jugadorn1= new Jugador("jose","martinez","ssh", Jugador.Posicion.Mediocampista);
        Equipo equipo = new Equipo(1645,"ruleta gang");
        Equipo equipo2 = new Equipo(165,"ruleta gang");

        JugadorDTO jugador1= new JugadorDTO(jugadorn1,equipo);

        jugador1.setApellido("romario");
        System.out.println(jugador1);


        ExamenMedico examen1 = new ExamenMedico(jugador1,66.2,1.78,false,"4");
        examen1.calcularIMC();

        Marcador marcador = new Marcador(equipo,"2:0",equipo2,"1");
        System.out.println(marcador);

        Arbitro arbitro =new Arbitro("hola","hola","1",200, Arbitro.Categoria.REGIONAL);

        PDDocument document = new PDDocument();
        /// CREAR PAGINA
        PDPage page = new PDPage();
        /// AGREGAR LA PAGINA AL DOCUMENTO
        document.addPage(page);
        /// CREAR UN STREAM PARA AGREGAR TEXTO
        PDPageContentStream stream = new PDPageContentStream(document, page);
        /// CREAR UN OBJETO CON LA FUENTE QUE VAMOS A USAR PARA EL TEXTO
        PDType1Font courierFont = new PDType1Font(Standard14Fonts.FontName.COURIER);
        /// INICIAMOS EL STREAM DE TEXTO
        stream.beginText();
        /// DEFINIMOS LA FUENTE Y EL TAMA~O PARA EL TITULO
        stream.setFont(courierFont, 24);
        /// DEFINIMOS LAS COORDENADAS PARA INICIAR EL TEXTO
        stream.newLineAtOffset(10,760 );
        /// MOSTRAMOS EL TEXTO/ TITULO
        stream.showText("Crear PDF con PDFBox en Java");
        /// DEFINIMOS EL LA FUENTE Y TAMA~O PARA LOS PARRAFOS
        stream.setFont(courierFont, 12);
        /// DEFINIMOS LAS COORDENADAS EN REFERENCIA A LA DEFINICION DE COORDENADAS ANTERIOR
        stream.newLineAtOffset(0, -10);
        /// MOSTRAMOS EL TEXTO DE UN PARRAFO
        stream.showText("Hola Mundo !!!");
        /// DEFINIMOS LAS COORDENADAS EN REFERENCIA A LA DEFINICION DE COORDENADAS ANTERIOR
        stream.newLineAtOffset(0, -10);
        /// MOSTRAMOS EL TEXTO DE OTRO PARRAFO
        stream.showText("Linea 3!");
        /// FINALIZAMOS EL STREAM DE TEXTO
        stream.endText();
        /// CERRAMOS EL STREAM
        stream.close();

        document.save("C:\\Users\\santi\\OneDrive\\Documentos\\Programacion 2\\DTO_Record\\src\\main\\java\\co\\edu\\uniquindio\\poo\\dto_record\\hola.pdf");

        document.close();


    }
}
