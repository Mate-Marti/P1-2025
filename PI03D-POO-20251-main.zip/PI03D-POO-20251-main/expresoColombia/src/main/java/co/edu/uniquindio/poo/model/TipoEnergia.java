package co.edu.uniquindio.poo.model;

/**
 * Enum que representa el tipo de energía de un Microbus.
 */
public enum TipoEnergia {
    ELECTRICO,
    COMBUSTION
}
