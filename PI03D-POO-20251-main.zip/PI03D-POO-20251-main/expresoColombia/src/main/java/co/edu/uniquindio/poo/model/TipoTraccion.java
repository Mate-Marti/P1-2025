package co.edu.uniquindio.poo.model;

/**
 * Enum que representa los tipos de tracción para vehículos tipo Van.
 */
public enum TipoTraccion {
    TRACCION_4X2,
    TRACCION_4X4
}
