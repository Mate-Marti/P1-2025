package co.edu.uniquindio.poo.model;

public enum Prioridad {
    ALTA,
    MEDIA,
    BAJA
}
