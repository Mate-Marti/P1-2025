package co.edu.uniquindio.poo.model;

public interface GestionTareas {

    public String asignarTarea(Colaborador colaborador, Tarea tarea);

}
