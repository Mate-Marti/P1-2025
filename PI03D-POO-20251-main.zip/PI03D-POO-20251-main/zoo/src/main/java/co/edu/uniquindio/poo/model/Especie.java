package co.edu.uniquindio.poo.model;

public enum Especie {
    MAMÍFEROS,
    AVES,
    REPTILES,
    ANFIBIOS,
    PECES
}
