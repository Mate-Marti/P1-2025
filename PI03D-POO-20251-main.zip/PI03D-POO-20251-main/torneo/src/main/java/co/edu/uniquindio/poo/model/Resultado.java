package co.edu.uniquindio.poo.model;

public record Resultado(String equipoGanador, String equipoPerdedor, int marcadorGanador, int marcadorPerdedor) {

}
