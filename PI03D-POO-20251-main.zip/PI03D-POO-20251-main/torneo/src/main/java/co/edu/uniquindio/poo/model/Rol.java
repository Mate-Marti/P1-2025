package co.edu.uniquindio.poo.model;

public enum Rol {
    LIDER,
    SOPORTE,
    ATACANTE;
}
