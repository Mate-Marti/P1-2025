package co.edu.uniquindio.poo;

public class Nota {
}
