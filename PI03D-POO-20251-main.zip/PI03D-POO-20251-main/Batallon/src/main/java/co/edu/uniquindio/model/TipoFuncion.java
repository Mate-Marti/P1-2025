package co.edu.uniquindio.model;

public enum TipoFuncion {
    LOGISTICA,
    COMUNICACIONES,
    MEDICO
}
