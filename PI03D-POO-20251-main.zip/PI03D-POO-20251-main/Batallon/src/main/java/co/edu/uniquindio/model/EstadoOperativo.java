package co.edu.uniquindio.model;

public enum EstadoOperativo {
    DISPONIBLE,
    EN_MISION,
    EN_MANTENIMIENTO
}
