package co.edu.uniquindio.main;

public class Main {
    public static void main(String[] args) {

//        Vehiculo newVehiculo = new VehiculoTransporteTropa("1001",
//                "2005", 2000, 100,
//                100);
//
//        VehiculoTransporteTropa newVehiculo2 = new VehiculoTransporteTropa("1001",
//                "2005", 2000, 100,
//                100);
    }
}