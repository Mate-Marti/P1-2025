package co.edu.uniquindio.model;

import static org.junit.jupiter.api.Assertions.*;

class BatallonTest {

}